"""
Задание №2
"""
nums= [
'+77053183958','+77773183958','87773183958','+(777)73183958','+7(777)-731-83-58','+7(777) 731 83 58']
user_input = input("Введите номера телефона через точку с запятой:")
user_input_list = user_input.split(";")

for number in user_input_list:
    number_clean = ((number.replace(' ', '').replace('+', '')
                             .replace('(', '')).replace(')', '')
                            .replace('-', ''))
    number_clean_plus = ((number.replace(' ', '')
                             .replace('(', '')).replace(')', '')
                            .replace('-', ''))
    if len(number_clean) != 11:
        raise ValueError(f'Номер {number} больше или меньше 11 знаков')
    if not (number_clean_plus[0] == "8" or number_clean_plus[0:2] == "+7"):
        raise ValueError(f"Номер {number} не начинается на 8 или +7!")
    if not number_clean.isdigit():
        raise ValueError(f"Номер {number} состоит не только из цифр!")
