"""
Задача №1
"""
data_list = ['1','2','3','4d', 5]
new_data_list = []
for data in data_list:
    try:
        new_data_list.append(int(data))
    except ValueError:
        print(f'Данные "{data}" не валидны')
        continue
print(new_data_list)
